//
//  Faces.swift
//  Faces
//
//  Created by Reem alsharif on 8/4/17.
//  Copyright © 2017 Reem alsharif. All rights reserved.
//

import UIKit

enum MyColor {
    case navigationBarBackgroundColor
    case navigationTintCololr
}

extension MyColor {
    var value: UIColor {
        get {
            switch self {
            case .navigationBarBackgroundColor:
                return UIColor(red: 67/255, green: 173/255, blue: 247/255, alpha: 1.0)
            case .navigationTintCololr:
                return UIColor.white
            }
        }
    }
}

@IBDesignable
class Faces: UIView {
    
    
    
            

    
    
    @IBInspectable
    var scale:CGFloat = 0.9
    
    // from here we can change the eyes open or close
    @IBInspectable
    var eyesOpen:Bool = true
    @IBInspectable
    var lineWidth: CGFloat = 5.0
    //to change smile
    @IBInspectable
    var mouthCurvatrue: Double = 0.2
    @IBInspectable
    var color: UIColor = UIColor.white
    
    private var skullRadius: CGFloat {
    return min(bounds.size.width, bounds.size.height) / 2 * scale
    }
    
    
    private var skullCenter: CGPoint{
        
    return CGPoint(x: bounds.midX, y: bounds.midY)
    }

    
    private enum Eye {
    case left
    case right
    
    }
    private func pathForEye(_ eye:Eye) ->UIBezierPath
    {
        func centerOfEye(_ eye: Eye) ->CGPoint{
            let eyeOffset = skullRadius / Ratios.skullRadiusToEyeOffset
            var eyeCenter = skullCenter
            eyeCenter.y -= eyeOffset
            eyeCenter.x += ((eye == .left) ? -1: 1) * eyeOffset
            return eyeCenter
            
            
        
        
        
        }
        
        let eyeRadius = skullRadius / Ratios.skullRadiusToEyeRadius
        let eyeCenter = centerOfEye(eye)
        
        let path: UIBezierPath
        if eyesOpen{
        path = UIBezierPath(arcCenter: eyeCenter, radius: eyeRadius, startAngle: 0, endAngle: CGFloat.pi * 2, clockwise: true)
        
        }else{
        path = UIBezierPath()
            path.move(to: CGPoint(x:eyeCenter.x - eyeRadius, y: eyeCenter.y) )
                path.addLine(to: CGPoint (x: eyeCenter.x + eyeRadius, y: eyeCenter.y))
        
        }
        
        
        path.lineWidth = 5.0
        return path
        
        
    }
    
    private func pathForMouth() -> UIBezierPath
    {

      let mouthWidth = skullRadius / Ratios.skullRadiusToMouthWidth
      let mouthHeight = skullRadius / Ratios.skullRadiusToMouthHeight
      let mouthOffset = skullRadius / Ratios.skullRadiusToEyeOffset
        
      let mouthRect = CGRect(
        x: skullCenter.x - mouthWidth / 2,
        y: skullCenter.y + mouthOffset,
        width: mouthWidth,
        height: mouthHeight
        
        
        )
        
        let smileOffset = CGFloat(max(-1, min(mouthCurvatrue, 1))) * mouthRect.height
        
        let start = CGPoint(x: mouthRect.minX, y: mouthRect.midY)
        let end = CGPoint(x: mouthRect.maxX, y: mouthRect.midY)
        
        let cp1 = CGPoint(x: start.x + mouthRect.width / 3, y: start.y + smileOffset)
        let cp2 = CGPoint(x: end.x - mouthRect.width / 3, y: start.y + smileOffset)
        let path = UIBezierPath()
        path.move(to: start)
        path.addCurve(to: end, controlPoint1: cp1, controlPoint2: cp2)
        path.lineWidth = 5.0
        return path
        
        
        
    
        
    }
    
    
    
    private func pathForSkull() ->UIBezierPath{
        let path = UIBezierPath(arcCenter: skullCenter, radius: skullRadius, startAngle: 0, endAngle: 2 * CGFloat.pi, clockwise: false)
        path.lineWidth = 10.5
        return path
    
    }
       var vv = ViewController()
    
    override func draw(_ rect: CGRect) {
        
        UIColor.white.set()
        pathForSkull().stroke()
        pathForEye(.left).stroke()
        pathForEye(.right).stroke()
        pathForMouth().stroke()
        
        
        
        // Drawing code
    }
 
    
    private struct Ratios {
        static let skullRadiusToEyeOffset:CGFloat = 3
        static let skullRadiusToEyeRadius:CGFloat = 10
        static let skullRadiusToMouthWidth:CGFloat = 1
        static let skullRadiusToMouthHeight:CGFloat = 3
        static let skullRadiusToMouthOffset:CGFloat = 3
    
    
    
    
    }
    
    
   
        
    
    
  
    
    
    }
    
    
    

