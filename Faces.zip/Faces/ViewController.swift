//
//  ViewController.swift
//  Faces
//
//  Created by Reem alsharif on 8/4/17.
//  Copyright © 2017 Reem alsharif. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    @IBOutlet weak var lableQuote: UILabel!
    @IBOutlet weak var label: UILabel!
    // Swift 3:
    var quote = ["Without labor nothing prospers","All wealth is the product of labor","Keep fighting","No pain, no gain"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
         lableQuote.textAlignment = NSTextAlignment.center
        lableQuote.text = quote[generateRandomQuotes()]
        
    }
    
    func generateRandomQuotes() -> Int {
        let randomQute = arc4random_uniform(UInt32(quote.count))
        return Int(randomQute)
        
    }
    
    
    @IBAction func Date(_ sender: UIButton) {
        
        let date = NSDate()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let str = dateFormatter.string(from: date as Date)
        label.text =  str
        
    }
    
    
    @IBAction func Quotes(_ sender: UIButton) {
        lableQuote.textAlignment = NSTextAlignment.center
        lableQuote.text = quote[generateRandomQuotes()]
    }
    
    
    
  
}
